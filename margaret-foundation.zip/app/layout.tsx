import type React from "react"
import type { Metadata } from "next"
import { Inter, Merriweather } from "next/font/google"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const merriweather = Merriweather({
  weight: ["300", "400", "700"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-merriweather",
})

export const metadata: Metadata = {
  title: "Margaret Foundation for the Blind - Empowering Lives Through Support",
  description:
    "Supporting visually impaired individuals through education, training, and community programs. Donate today to help change lives.",
  keywords: "blind, visually impaired, foundation, charity, donation, accessibility, braille, education",
  authors: [{ name: "Margaret Foundation for the Blind" }],
  openGraph: {
    title: "Margaret Foundation for the Blind",
    description:
      "Empowering the blind. Changing lives. Support our mission to help visually impaired individuals thrive.",
    type: "website",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${merriweather.variable}`}>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#000000" />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
