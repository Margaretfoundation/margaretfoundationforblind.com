import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export default function Page() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Margaret Foundation for the Blind Families</h1>
              <p className="text-sm text-slate-600">Empowering families through support and advocacy</p>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#mission" className="text-slate-700 hover:text-blue-600 font-medium">
                Our Mission
              </a>
              <a href="#impact" className="text-slate-700 hover:text-blue-600 font-medium">
                Impact
              </a>
              <a href="#get-involved" className="text-slate-700 hover:text-blue-600 font-medium">
                Get Involved
              </a>
              <a href="#contact" className="text-slate-700 hover:text-blue-600 font-medium">
                Contact
              </a>
              <Button className="bg-blue-600 hover:bg-blue-700">Donate Now</Button>
            </nav>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-blue-50 to-slate-50">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 leading-tight">
                  Supporting Blind Families with <span className="text-blue-600">Hope & Resources</span>
                </h2>
                <p className="text-xl text-slate-700 mb-8 leading-relaxed">
                  Every family deserves support, understanding, and the tools to thrive. We provide comprehensive
                  assistance to families affected by blindness, creating pathways to independence and success.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
                    Donate Today
                  </Button>
                  <Button variant="outline" size="lg" className="text-lg px-8 py-3 bg-transparent">
                    Learn More
                  </Button>
                </div>
              </div>
              <div>
                <img
                  src="/family-photo.jpg"
                  alt="A loving family of four standing together outdoors - an elderly woman in traditional red clothing flanked by two younger women in matching yellow dresses and a man in a green shirt, representing the families we serve"
                  className="rounded-lg shadow-xl w-full h-auto brightness-110 contrast-105 saturate-105"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Mission & Story Section */}
        <section id="mission" className="py-20 bg-white">
          <div className="max-w-4xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Our Mission</h2>
              <p className="text-xl text-slate-700 leading-relaxed">
                Founded with love and dedication, the Margaret Foundation for the Blind Families exists to provide
                comprehensive support, resources, and advocacy for families navigating life with visual impairment.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-bold text-slate-900 mb-4">Margaret's Story</h3>
                <p className="text-slate-700 mb-4 leading-relaxed">
                  Margaret was a beacon of strength in her community, supporting families through the challenges of
                  blindness with unwavering compassion. Her legacy lives on through our foundation, continuing her
                  mission of hope and empowerment.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Today, we honor her memory by providing practical support, educational resources, and emotional
                  guidance to families who need it most. Every donation helps us extend Margaret's caring touch to more
                  families in need.
                </p>
              </div>
              <div className="bg-blue-50 p-8 rounded-lg">
                <h4 className="text-xl font-semibold text-slate-900 mb-4">What We Provide</h4>
                <ul className="space-y-3 text-slate-700">
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Educational resources and adaptive technology training</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Financial assistance for medical care and equipment</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Family counseling and peer support networks</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Advocacy for accessibility and inclusion</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Fundraising Goals Section */}
        <section className="py-20 bg-slate-50">
          <div className="max-w-4xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Current Fundraising Goal</h2>
              <p className="text-xl text-slate-700">Help us reach our goal to support 100 more families this year</p>
            </div>

            <Card className="max-w-2xl mx-auto">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">$50,000 Goal</CardTitle>
                <CardDescription>Supporting families with essential resources and care</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex justify-between text-sm text-slate-600 mb-2">
                    <span>Progress</span>
                    <span>$32,500 raised (65%)</span>
                  </div>
                  <Progress value={65} className="h-3" />
                </div>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">127</div>
                    <div className="text-sm text-slate-600">Families Helped</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">$32,500</div>
                    <div className="text-sm text-slate-600">Raised</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-slate-600">$17,500</div>
                    <div className="text-sm text-slate-600">Remaining</div>
                  </div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3">Contribute Now</Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Impact & Testimonials */}
        <section id="impact" className="py-20 bg-white">
          <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Our Impact</h2>
              <p className="text-xl text-slate-700">Real stories from families we've supported</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card>
                <CardContent className="p-6">
                  <p className="text-slate-700 mb-4 italic">
                    "The Margaret Foundation gave us hope when we felt lost. Their support helped our daughter adapt to
                    her new reality and thrive in school."
                  </p>
                  <div className="text-sm text-slate-600">
                    <strong>- Sarah M.</strong>, Mother of 3
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <p className="text-slate-700 mb-4 italic">
                    "Thanks to the foundation's technology training program, I learned to use adaptive tools that
                    transformed my daily life and independence."
                  </p>
                  <div className="text-sm text-slate-600">
                    <strong>- James K.</strong>, Program Participant
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <p className="text-slate-700 mb-4 italic">
                    "The emotional support and counseling services helped our entire family navigate this journey
                    together with strength and unity."
                  </p>
                  <div className="text-sm text-slate-600">
                    <strong>- Maria L.</strong>, Family Member
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Get Involved Section */}
        <section id="get-involved" className="py-20 bg-blue-50">
          <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Get Involved</h2>
              <p className="text-xl text-slate-700">There are many ways to support our mission</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M4 4a2 2 0 00-2 2v1.161l8.441 4.221a1.25 1.25 0 001.118 0L20 7.161V6a2 2 0 00-2-2H4z" />
                      <path d="M2 9.839V15a2 2 0 002 2h12a2 2 0 002-2V9.839l-8.118 4.059a3.25 3.25 0 01-2.764 0L2 9.839z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Donate</h3>
                  <p className="text-slate-700 text-sm">
                    Make a financial contribution to directly support families in need
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Volunteer</h3>
                  <p className="text-slate-700 text-sm">
                    Share your time and skills to help families in your community
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Advocate</h3>
                  <p className="text-slate-700 text-sm">
                    Help raise awareness and advocate for accessibility in your community
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Share</h3>
                  <p className="text-slate-700 text-sm">
                    Spread the word about our mission through social media and networks
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Transparency Section */}
        <section className="py-20 bg-white">
          <div className="max-w-4xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Financial Transparency</h2>
              <p className="text-xl text-slate-700">
                We believe in complete transparency about how your donations are used
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">85%</div>
                <div className="text-slate-700">Direct Family Support</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-green-600 mb-2">10%</div>
                <div className="text-slate-700">Program Operations</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-slate-600 mb-2">5%</div>
                <div className="text-slate-700">Administrative Costs</div>
              </div>
            </div>

            <div className="bg-slate-50 p-8 rounded-lg">
              <h3 className="text-xl font-semibold text-slate-900 mb-4">Where Your Money Goes</h3>
              <div className="space-y-3 text-slate-700">
                <div className="flex justify-between">
                  <span>Medical equipment and assistive technology</span>
                  <span className="font-medium">40%</span>
                </div>
                <div className="flex justify-between">
                  <span>Educational programs and training</span>
                  <span className="font-medium">25%</span>
                </div>
                <div className="flex justify-between">
                  <span>Family counseling and support services</span>
                  <span className="font-medium">20%</span>
                </div>
                <div className="flex justify-between">
                  <span>Program operations and outreach</span>
                  <span className="font-medium">10%</span>
                </div>
                <div className="flex justify-between">
                  <span>Administrative and fundraising costs</span>
                  <span className="font-medium">5%</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-slate-50">
          <div className="max-w-6xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">Contact & Support</h2>
              <p className="text-xl text-slate-700">Get in touch with us - we're here to help</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <Card>
                <CardHeader>
                  <CardTitle>Get in Touch</CardTitle>
                  <CardDescription>Reach out to us directly for support or questions</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                        <path
                          fillRule="evenodd"
                          d="M2 3.5A1.5 1.5 0 013.5 2h1.148a1.5 1.5 0 011.465 1.175l.716 3.223a1.5 1.5 0 01-1.052 1.767l-.933.267c-.41.117-.643.555-.48.95a11.542 11.542 0 006.254 6.254c.395.163.833-.07.95-.48l.267-.933a1.5 1.5 0 011.767-1.052l3.223.716A1.5 1.5 0 0118 15.352V16.5a1.5 1.5 0 01-1.5 1.5H15c-1.149 0-2.263-.15-3.326-.43A13.022 13.022 0 012.43 8.326 13.019 13.019 0 012 5V3.5z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium text-slate-900">Phone</p>
                      <a href="tel:+12404627510" className="text-blue-600 hover:text-blue-800 font-medium">
                        +1240 462 7510
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M3 4a2 2 0 00-2 2v1.161l8.441 4.221a1.25 1.25 0 001.118 0L20 7.161V6a2 2 0 00-2-2H3z" />
                        <path d="M2 9.839V15a2 2 0 002 2h12a2 2 0 002-2V9.839l-8.118 4.059a3.25 3.25 0 01-2.764 0L2 9.839z" />
                      </svg>
                    </div>
                    <div>
                      <p className="font-medium text-slate-900">Email</p>
                      <a
                        href="mailto:margaretfoundationforblind@gmail.com"
                        className="text-blue-600 hover:text-blue-800 font-medium"
                      >
                        margaretfoundationforblind@gmail.com
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Send us a Message</CardTitle>
                  <CardDescription>We'll get back to you within 24 hours</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-2">
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                        aria-describedby="name-help"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                        aria-describedby="email-help"
                      />
                    </div>
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-2">
                        Subject
                      </label>
                      <input
                        type="text"
                        id="subject"
                        name="subject"
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-2">
                        Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows={4}
                        className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                        aria-describedby="message-help"
                      ></textarea>
                    </div>
                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <h3 className="text-xl font-bold mb-4">Margaret Foundation for the Blind Families</h3>
              <p className="text-slate-300 mb-4">
                Dedicated to supporting families affected by blindness through comprehensive resources, advocacy, and
                community support.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-slate-300 hover:text-white" aria-label="Facebook">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </a>
                <a href="#" className="text-slate-300 hover:text-white" aria-label="Twitter">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                  </svg>
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <a href="#mission" className="hover:text-white">
                    Our Mission
                  </a>
                </li>
                <li>
                  <a href="#impact" className="hover:text-white">
                    Impact Stories
                  </a>
                </li>
                <li>
                  <a href="#get-involved" className="hover:text-white">
                    Get Involved
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-white">
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-slate-300">
                <p>
                  Phone:{" "}
                  <a href="tel:+12404627510" className="hover:text-white">
                    +1240 462 7510
                  </a>
                </p>
                <p>
                  Email:{" "}
                  <a href="mailto:margaretfoundationforblind@gmail.com" className="hover:text-white">
                    margaretfoundationforblind@gmail.com
                  </a>
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 Margaret Foundation for the Blind Families. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
